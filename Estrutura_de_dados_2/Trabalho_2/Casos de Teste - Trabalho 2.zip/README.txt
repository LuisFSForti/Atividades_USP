Arquivo zip gerado em: 05/05/2024 22:24:10 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Trabalho 2