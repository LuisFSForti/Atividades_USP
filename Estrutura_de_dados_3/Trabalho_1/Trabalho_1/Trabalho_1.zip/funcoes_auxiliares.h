//Luis Filipe Silva Forti - 14592348
//Lucien Rodrigues Franzen - 14554835

//Trabalho 1 de ED3

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifndef FUNCOES_AUXILIARES_H_INCLUDED
#define FUNCOES_AUXILIARES_H_INCLUDED

//Separa os dados de entrada no intervalo nroDado entre dois sep, salvando em saida
void SepararDado(char* entrada, char* saida, int nroDado, char sep);

#endif // FUNCOES_AUXILIARES_H_INCLUDED
