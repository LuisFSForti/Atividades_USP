#include "ListaDeAdjacencias.h"

ListaDeAdjacencias::ListaDeAdjacencias(std::fstream &arqEntrada)
{
    arqEntrada.seekg(0);

    char status;
    arqEntrada.read(&status, sizeof(char));

    if(status == '0')
    {
        std::cout << "Falha no processamento do arquivo.";
        arqEntrada.close();
        return;
    }

    int qtd;
    arqEntrada.seekg(sizeof(char) + sizeof(int));
    arqEntrada.read((char*)&qtd, sizeof(int));
    arqEntrada.seekg(1600);

    for(int i = 0; i < qtd * 160; i += 160)
    {
        SerVivo serVivo(arqEntrada);

        int posSer;

        if(this->EncontrarSerVivo(serVivo.Alimento()) == -1)
        {
            posSer = this->EncontrarPosInsercao(serVivo.Alimento());
            this->_listaAdj.insert(this->_listaAdj.begin() + posSer, Vertice(SerVivo(serVivo.Alimento())));
        }

        posSer = this->EncontrarPosInsercao(serVivo.Nome());

        if(this->EncontrarSerVivo(serVivo.Nome()) == -1)
        {
            this->_listaAdj.insert(this->_listaAdj.begin() + posSer, Vertice(serVivo));
            continue;
        }

        if(this->_listaAdj.at(posSer).GrauDeSaida() > 0)
        {
            this->_listaAdj.at(posSer).IncluirAlimento(serVivo);
        }
        else
        {
            this->_listaAdj.at(posSer) = *new Vertice(serVivo);
        }
    }

    for(auto& atual : this->_listaAdj)
    {
        atual.SetGrauDeEntrada(this->FindPredadores(atual.Origem().Nome()).size());
    }
}

ListaDeAdjacencias::~ListaDeAdjacencias()
{
    this->_listaAdj.clear();
}

int ListaDeAdjacencias::EncontrarSerVivo(std::string nome) const
{
    for(int i = 0; i < (int)this->_listaAdj.size(); i++)
    {
        int relacao = nome.compare(this->_listaAdj.at(i).Origem().Nome());
        if(relacao == 0)
        {
            return i;
        }
        if(relacao < 0)
        {
            return -1;
        }
    }

    return -1;
}


int ListaDeAdjacencias::EncontrarPosInsercao(std::string nome) const
{
    for(int i = 0; i < (int)this->_listaAdj.size(); i++)
    {
        if(nome.compare(this->_listaAdj.at(i).Origem().Nome()) <= 0)
        {
            return i;
        }
    }

    return this->_listaAdj.size();
}

int ListaDeAdjacencias::ContarCirculos(std::vector<std::string>* brancos, std::vector<std::string>* cinzas, int serVivoAtual) const
{
    //Procura a posicao dele nos brancos
    for(int i = 0; i < (int)brancos->size(); i++)
    {
        //Se encontrou
        if(brancos->at(i).compare(this->_listaAdj.at(serVivoAtual).Origem().Nome()) == 0)
        {
            //Deleta ele
            brancos->erase(brancos->begin() + i);
        }
    }

    int qtd = 0;

    //Verifica se tem presas
    if(this->_listaAdj.at(serVivoAtual).GrauDeSaida() != 0)
    {
        int pos = cinzas->size();
        cinzas->push_back(this->_listaAdj.at(serVivoAtual).Origem().Nome());

        for(auto& aresta : this->_listaAdj.at(serVivoAtual).ListaAlimentos())
        {
            bool procurou = false;

            //Procura a posicao dele nos brancos
            for(int i = 0; i < (int)brancos->size(); i++)
            {
                //Se encontrou
                if(brancos->at(i).compare(aresta.Valor()) == 0)
                {
                    qtd += this->ContarCirculos(brancos, cinzas, this->EncontrarSerVivo(aresta.Valor()));
                    procurou = true;
                    break;
                }
            }

            if(procurou)
                continue;

            //Procura a posicao dele nos cinzas
            for(int i = 0; i < (int)cinzas->size(); i++)
            {
                //Se encontrou
                if(cinzas->at(i).compare(aresta.Valor()) == 0)
                {
                    qtd++;
                }
            }
        }

        cinzas->erase(cinzas->begin() + pos);
    }

    //Como ja foi removido dos brancos e dos cinzas, ele eh classificado como preto
    return qtd;
}

std::vector<std::string> ListaDeAdjacencias::FindPredadores(std::string nome) const
{
    std::vector<std::string> predadores;

    for(auto& atual : this->_listaAdj)
    {
        if(atual.AlimentaDe(nome))
            predadores.push_back(atual.Origem().Nome());
    }

    return predadores;
}

int ListaDeAdjacencias::ContarQuantidadeCiclos() const
{
    std::vector<std::string>* brancos = new std::vector<std::string>();
    std::vector<std::string>* cinzas = new std::vector<std::string>();

    for(auto& serVivo : this->_listaAdj)
    {
        brancos->push_back(serVivo.Origem().Nome());
    }

    int qtd = 0;

    while(brancos->size() > 0)
    {
        qtd += this->ContarCirculos(brancos, cinzas, this->EncontrarSerVivo(brancos->at(0)));
    }

    return qtd;
}

std::ostream& operator<<(std::ostream& out, const ListaDeAdjacencias& lista)
{
    for(auto const& atual : lista._listaAdj)
    {
        out << atual;
    }

    return out;
}
