//Gustavo Curado Ribeiro - 14576732
//Luis Filipe Silva Forti - 14592348
//Miguel Rodrigues Fonseca - 14682196

//LCD
#include <LiquidCrystal.h>
//MicroSD
#include <FS.h>
#include <SD.h>
#include <SPI.h>

/* ========= PINOS ========= */
// Motor 1 (front-left)
#define M1_STEP 13
#define M1_DIR  12

// Motor 2 (front-right)
#define M2_STEP 14
#define M2_DIR  32

// Motor 3 (rear-left)
#define M3_STEP 26
#define M3_DIR  15

// Motor 4 (rear-right)
#define M4_STEP 27
#define M4_DIR  33

// ENABLE comum
#define EN_PIN 25

/* ========= JOYSTICK ========= */
#define JOY_X 34   // esquerda / direita  -> pitch
#define JOY_Y 35   // cima / baixo        -> throttle

/* ========= CONTROLE ========= */
long throttle = 2500;
long pitch    = 0;

const long THROTTLE_MIN = 200;
const long THROTTLE_MAX = 4800;
const long PITCH_MAX    = 2500;

/* ========= JOYSTICK CONFIG ========= */
const int ADC_MAX = 4095;
const int DEADZONE = 150;

/* ========= TIMERS ========= */
unsigned long lastStepM1 = 0;
unsigned long lastStepM2 = 0;
unsigned long lastStepM3 = 0;
unsigned long lastStepM4 = 0;

/* ========= LCD 16x2 ========= */
#define LCD_RS  4
#define LCD_E   16
#define LCD_D4  17
#define LCD_D5  18
#define LCD_D6  19
#define LCD_D7  21

LiquidCrystal lcd(LCD_RS, LCD_E, LCD_D4, LCD_D5, LCD_D6, LCD_D7);

/* ===== LCD TIMER ===== */
unsigned long lastLcdUpdate = 0;
const unsigned long LCD_INTERVAL = 200; // ms

const unsigned int PULSE_WIDTH_US = 100;

/* ===== MicroSD ===== */

#define pinSD 23
#define pinSCK 5
#define pinMISO 0
#define pinMOSI 22

#define enderecoLog "/log.txt"
#define intervaloRegistros 2000

int ultimoRegistro = 0;
SPIClass spiSD(VSPI);
File logFile;

/* ========= FUNÇÕES ========= */
//Pega o tempo que esteve ligado e transforma para uma string
//Não está tratando dias, pois assume-se que o avião não vai ficar mais de 24h ligado direto
String GetTempo()
{
  unsigned long tempo = millis();

  unsigned long segundosTotais = tempo/1000;
  unsigned long minutosTotais = segundosTotais/60;
  unsigned long horasTotais = minutosTotais/60;

  int segundos = segundosTotais % 60;
  int minutos = minutosTotais % 60;
  int horas = horasTotais % 24;

  //Coloca "0" se o número não tiver 2 dígitos
  String sHoras = (horas < 10) ? "0" + String(horas) : String(horas);
  String sMinutos = (minutos < 10) ? "0" + String(minutos) : String(minutos);
  String sSegundos = (segundos < 10) ? "0" + String(segundos) : String(segundos);

  return sHoras + "h - " + sMinutos + "m - " + sSegundos + "s";
}

//Lê todos os registros do arquivo e passa pro serial
void LerArquivo() {
  File file = SD.open(enderecoLog);
  if(!file){
    Serial.println("\nFalha ao abrir arquivo para leitura");
    return;
  }
  
  Serial.println("\n--- CONTEÚDO DO ARQUIVO LOG.TXT ---");
  while(file.available()){
    Serial.write(file.read());
  }
  Serial.println("--- FIM DO ARQUIVO ---");
  file.close();
}

//Registra os dados
void AtualizarArquivo(float movimentoVertical, float movimentoHorizontal)
{
  //Se o arquivo foi aberto
  if(logFile)
  {
    logFile.print(GetTempo() + ": ");

    if (movimentoVertical > DEADZONE) {
      logFile.println("DESCENDO");
    }
    else if (movimentoVertical < -DEADZONE) {
      logFile.println("SUBINDO");
    }
    else if (movimentoHorizontal > DEADZONE) {
      logFile.println("PRA TRAS");
    }
    else if (movimentoHorizontal < -DEADZONE) {
      logFile.println("PRA FRENTE");
    }
    else {
      logFile.println("PARADO");
    }

    //flush() para não precisar ficar abrindo e fechando o arquivo
    logFile.flush();

    //Escreve os registros, para mostrar o funcionamento
    LerArquivo();
  }
}

void pulseStep(int pin) {
  digitalWrite(pin, HIGH);
  delayMicroseconds(PULSE_WIDTH_US);
  digitalWrite(pin, LOW);
}

void computeDelays(long baseThrottle, long pitchValue,
                   long &delayFront, long &delayBack) {

  long p = constrain(pitchValue, -PITCH_MAX, PITCH_MAX);

  delayFront = baseThrottle - p;
  delayBack  = baseThrottle + p;

  delayFront = constrain(delayFront, THROTTLE_MIN, THROTTLE_MAX);
  delayBack  = constrain(delayBack,  THROTTLE_MIN, THROTTLE_MAX);
}

/* ========= SETUP ========= */
void setup() {
  Serial.begin(115200);
  Serial.println("=== STEP QUADCOPTER - JOYSTICK ===");

  pinMode(M1_STEP, OUTPUT);
  pinMode(M1_DIR, OUTPUT);
  pinMode(M2_STEP, OUTPUT);
  pinMode(M2_DIR, OUTPUT);
  pinMode(M3_STEP, OUTPUT);
  pinMode(M3_DIR, OUTPUT);
  pinMode(M4_STEP, OUTPUT);
  pinMode(M4_DIR, OUTPUT);

  pinMode(EN_PIN, OUTPUT);
  digitalWrite(EN_PIN, LOW); // habilita A4988

  // Sentido estilo quadcóptero
  digitalWrite(M1_DIR, HIGH);
  digitalWrite(M2_DIR, LOW);
  digitalWrite(M3_DIR, LOW);
  digitalWrite(M4_DIR, HIGH);

  /* ===== LCD ===== */
  lcd.begin(16, 2);
  lcd.clear();
  lcd.print("Drone");
  lcd.setCursor(0, 1);
  lcd.print("Inicializando");
  delay(1500);
  lcd.clear();

  /* ===== MicroSD ===== */
  //Tenta configurar o MicroSD
  spiSD.begin(pinSCK, pinMISO, pinMOSI, pinSD);
  if (!SD.begin(pinSD, spiSD, 4000000))
  {
    Serial.println("Falha na montagem do cartão!");
    return;
  }
  Serial.println("Cartão reconhecido");

  //Cria/abre o arquivo de log
  //Como é uma simulação no Wokwi, sempre criará um novo
  logFile = SD.open(enderecoLog, FILE_APPEND);
  if(logFile){
    Serial.println("Arquivo aberto com sucesso!");
    logFile.println("--- Nova Sessão Iniciada ---");
  }
  else
  {
    logFile.println("Erro ao abrir o arquivo de log!");
    return;
  }
}

/* ========= LOOP ========= */
void loop() {

  /* ======= LEITURA DO JOYSTICK ======= */
  int joyX = analogRead(JOY_X);
  int joyY = analogRead(JOY_Y);

  int center = ADC_MAX / 2;

  /* --- PITCH (X) --- */
  int dx = joyX - center;
  if (abs(dx) < DEADZONE) dx = 0;

  pitch = map(dx,
              -center, center,
              -PITCH_MAX, PITCH_MAX);

  /* --- THROTTLE (Y) --- */
  int dy = center - joyY; // cima = positivo
  if (abs(dy) < DEADZONE) dy = 0;

  throttle = map(dy,
                 -center, center,
                 THROTTLE_MIN, THROTTLE_MAX);

  throttle = constrain(throttle, THROTTLE_MIN, THROTTLE_MAX);

  /* ======= CONTROLE DOS MOTORES ======= */
  long delayFront, delayBack;
  computeDelays(throttle, pitch, delayFront, delayBack);

  unsigned long now = micros();

  if (now - lastStepM1 >= delayFront) {
    lastStepM1 = now;
    pulseStep(M1_STEP);
  }

  if (now - lastStepM2 >= delayFront) {
    lastStepM2 = now;
    pulseStep(M2_STEP);
  }

  if (now - lastStepM3 >= delayBack) {
    lastStepM3 = now;
    pulseStep(M3_STEP);
  }

  if (now - lastStepM4 >= delayBack) {
    lastStepM4 = now;
    pulseStep(M4_STEP);
  }

  /* ======= LCD (NAO BLOQUEANTE) ======= */
  unsigned long nowMs = millis();

  if (nowMs - lastLcdUpdate >= LCD_INTERVAL) {
    lastLcdUpdate = nowMs;

    lcd.setCursor(0, 0);
    lcd.print("Movimento:     ");

    lcd.setCursor(0, 1);

    if (dy > DEADZONE) {
      lcd.print("DESCENDO        ");
    }
    else if (dy < -DEADZONE) {
      lcd.print("SUBINDO       ");
    }
    else if (dx > DEADZONE) {
      lcd.print("PRA TRAS    ");
    }
    else if (dx < -DEADZONE) {
      lcd.print("PRA FRENTE   ");
    }
    else {
      lcd.print("PARADO         ");
    }
  }

  //Se deu o intervalo entre registros
  if (ultimoRegistro + intervaloRegistros < millis())
  {
    AtualizarArquivo(dy, dx);
    ultimoRegistro += intervaloRegistros;
  }
}
